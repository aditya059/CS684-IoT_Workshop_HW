import time
from api import ServerApi
from time import sleep

s = ServerApi()
s.login("kachraseth@cs684.edu", "kachraseth")
id2 = ""

def first_use_case() -> None:
    global id2
    """
    Complete the below steps
    1. Create 2 things, "Device1" and "Device2"
    2. Delete "Device1"
    3. Update name of "Device2" to "device-2"
    4. Loop 5 times
    4.1 Report random (arbitrary) values for temperature and humidity on "device-2"
    4.2 Add a delay of 1 second
    4.3 Listen for RPC commands if any.

    The default baseUrl to use is https://apihptu.e-yantra.org/api

    NOTE: Please use the username and password provided to you by e-Yantra team.
    Contact e-Yantra team if not received.
    """

    id1 = s.create_thing("Device1")
    id1 = id1["id"]
    id2 = s.create_thing("Device2")
    id2 = id2["id"]
    s.delete_thing(id1)
    s.update_thing(id2, "device-2")
    ac_tkn2 = s.client_token(id2)
    for i in range(5):
        # values for temperature and humidity
        data = {
                "temperature": i*10,
                "humidity": i*12,
                }
        s.add_telemetry(access_token=ac_tkn2, data=data)
        recv = s.get_thing_telemetry(id2, "2020-02-19 00:00:00", "2022-02-19 16:45:00")
        print("Telemetry: ", recv)
        sleep(1)
        # listen for RPC commands if any
        s.receive_rpc(ac_tkn2)

def second_use_case(thing_id) -> None:
    """
    Complete the below steps for a thing with id `thing_id`
    1. Get data between time '2017-10-30 09:00:00' to '2021-06-10 17:00:00'.
    Use ServerApi::get_thing_telemetry().
    2. Send RPC command:- method: 'setTap', params: True

    The default baseUrl to use is https://apihptu.e-yantra.org/api

    NOTE: Please use the username and password provided to you by e-Yantra team.
    Contact e-Yantra team if not received.
    """
    s.get_thing_telemetry(thing_id, '2017-10-30 09:00:00', '2021-06-10 17:00:00')
    s.send_rpc(thing_id, "setTap", True)

if __name__ == "__main__":
    first_use_case()
    print("---------------------------------------")
    second_use_case(id2)  # you can enter your thing_id here
