const int buttonPin = 0;     // the number of the pushbutton pin
const int ledPin =  2;      // the number of the LED pin
volatile int buttonState = HIGH;

void setup() {
  // initialize serial:
  Serial.begin(115200);
  pinMode(ledPin, OUTPUT);
  // initialize the pushbutton pin as an input:
  pinMode(buttonPin, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(buttonPin), pin_ISR, CHANGE);
  Serial.println("First heyyy!");
}

void pin_ISR() {
  buttonState = digitalRead(buttonPin);
}

void loop() {
  // if there's any serial available, read it:
  if (buttonState == LOW) {
    Serial.println("Button Pressed");
    buttonState = HIGH;
  }
  while (Serial.available() > 0) {
    
    String data = Serial.readString();
    // check if the pushbutton is pressed. If it is, the buttonState is HIGH:
    if (data[0] == '0' || data[0] == '1') {
      switch (data[0]) //Selection Control Statement  
      {
          case '0':  
              digitalWrite(ledPin, HIGH); // Sets the led ON  
              break;  
          case '1':  
              digitalWrite(ledPin, LOW); //Sets the led OFF  
              break;  
      }  
    }
    else {
      // echo
      Serial.println(data);  
    }
  }
}